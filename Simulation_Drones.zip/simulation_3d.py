"""
simulation_3d.py
================
Unified 3D Real-World MuJoCo Flight Simulation for Tarot 650 Quadrotor UAV.
Features Dynamic 3D Wind, Animated Falling Rain, Real-Time Sensor Diagnostics,
and Fault-Tolerant Multi-Branch Estimation (Hamadi et al., 2022).

Usage:
    python simulation_3d.py              # Interactive Situation Selection Menu
    python simulation_3d.py --situation 1 # Situation 1: GPS Hardware Fault (+5m at t=7.0s)
    python simulation_3d.py --situation 2 # Situation 2: Lidar Hardware Fault (-1m at t=17.8s)
    python simulation_3d.py --situation 3 # Situation 3: Software Altitude Covariance Fault (KF1 P_z = -0.1)
    python simulation_3d.py --situation 4 # Situation 4: Software Position Covariance Fault (KF1 P_xy = -0.01)

Interactive Controls:
    Left Mouse Drag   : Orbit 360° camera around the flying drone
    Right Mouse Drag  : Pan camera view across the airfield
    Mouse Scroll Wheel: Zoom in / out to inspect drone details up close
    Spacebar          : Pause / Resume simulation
    Esc               : Exit viewer
"""

import sys
import argparse
import time
import numpy as np
import mujoco
import mujoco.viewer

# ── Import Core Algorithms & Estimation Blocks ──────────────────────────────
from drone_core import (
    SensorBlock, EKF, DynamicModelBranch, WeightedAverageVoter, PDController,
    TH_GPS, TH_LIDAR, TH_IMU, VOTER_A_XY, VOTER_N_XY, VOTER_A_Z, VOTER_N_Z
)

XML_PATH = 'tarot650_3d.xml'


def quat_to_euler(q: np.ndarray) -> np.ndarray:
    """Convert quaternion [w, x, y, z] to Euler angles [phi, theta, psi]."""
    w, x, y, z = q
    phi   = np.arctan2(2*(w*x + y*z), 1 - 2*(x**2 + y**2))
    theta = np.arcsin(np.clip(2*(w*y - z*x), -1.0, 1.0))
    psi   = np.arctan2(2*(w*z + x*y), 1 - 2*(y**2 + z**2))
    return np.array([phi, theta, psi])


# ─────────────────────────────────────────────────────────────────────────────
# 3D ANIMATED RAIN SYSTEM
# ─────────────────────────────────────────────────────────────────────────────
class RainParticleSystem:
    """Real-time 3D falling rain particles drifting with wind velocity."""

    def __init__(self, num_drops=280, box_size=(10.0, 10.0, 7.0)):
        self.num_drops = num_drops
        self.box_size = np.array(box_size)
        self.fall_speed = 14.0  # m/s terminal velocity
        self.drop_length = 0.25

        rng = np.random.default_rng(123)
        self.rel_pos = rng.uniform(-self.box_size / 2, self.box_size / 2, size=(num_drops, 3))
        self.color = np.array([0.72, 0.85, 1.0, 0.30], dtype=np.float32)

    def update(self, dt: float, wind_vel: np.ndarray):
        vel = np.array([wind_vel[0], wind_vel[1], -self.fall_speed])
        self.rel_pos += vel * dt

        half = self.box_size / 2
        for i in range(3):
            self.rel_pos[:, i] = ((self.rel_pos[:, i] + half[i]) % self.box_size[i]) - half[i]

    def render(self, scn: mujoco.MjvScene, drone_center: np.ndarray, wind_vel: np.ndarray):
        fall_dir = np.array([wind_vel[0] * 0.018, wind_vel[1] * 0.018, -self.drop_length])

        for pos in self.rel_pos:
            if scn.ngeom >= scn.maxgeom - 10:
                break
            p_top = drone_center + pos
            p_bot = p_top + fall_dir
            if p_bot[2] < 0.02:
                continue

            g = scn.geoms[scn.ngeom]
            mujoco.mjv_initGeom(g, mujoco.mjtGeom.mjGEOM_CAPSULE,
                                np.zeros(3), np.zeros(3), np.zeros(9),
                                self.color)
            mujoco.mjv_connector(g, mujoco.mjtGeom.mjGEOM_CAPSULE,
                                 0.0022, p_top, p_bot)
            scn.ngeom += 1


# ─────────────────────────────────────────────────────────────────────────────
# 3D FLIGHT SIMULATION & DIAGNOSTICS ENGINE
# ─────────────────────────────────────────────────────────────────────────────
class Tarot650Simulation3D:
    """Complete 3D Quadrotor Simulator with Weather, Sensors & Diagnostics."""

    def __init__(self, situation_id: int = 1):
        self.situation_id = situation_id
        self.dt = 0.005           # 200 Hz physics
        self.ctrl_period = 2      # 100 Hz flight control

        # Load MuJoCo Model
        self.model = mujoco.MjModel.from_xml_path(XML_PATH)
        self.data  = mujoco.MjData(self.model)

        rng = np.random.default_rng(42)

        # Redundant Sensor Blocks (SB1/SB2 on KF1, SB3/SB4 on KF2)
        self.sb1 = SensorBlock('SB1', rng)
        self.sb2 = SensorBlock('SB2', rng)
        self.sb3 = SensorBlock('SB3', rng)
        self.sb4 = SensorBlock('SB4', rng)

        # Multi-Branch State Estimators
        sw_Pz  = -0.1   if situation_id == 3 else None
        sw_Pxy = -0.01  if situation_id == 4 else None
        self.kf1 = EKF('KF1', software_fault_Pz=sw_Pz, software_fault_Pxy=sw_Pxy)
        self.kf2 = EKF('KF2')
        self.dm  = DynamicModelBranch(dt=self.dt * self.ctrl_period)

        # Weighted Average Voters
        self.voter_xy = WeightedAverageVoter(VOTER_A_XY, VOTER_N_XY)
        self.voter_z  = WeightedAverageVoter(VOTER_A_Z,  VOTER_N_Z)

        # Flight Controller
        self.ctrl = PDController()

        # Environmental Rain & Wind Models
        self.rain = RainParticleSystem(num_drops=280)
        self.mean_wind = np.array([3.8, 2.2, 0.0])
        self.current_wind = self.mean_wind.copy()

        # Telemetry & Fault Flags
        self.t               = 0.0
        self.fault_detected  = False
        self.fault_type      = "NONE"
        self.fault_name      = "None"
        self.recovery_active = False
        self.paused          = False

        # Live Sensor Metrics
        self.s12 = 1.0;  self.s13 = 1.0;  self.s23 = 1.0
        self.pos_gt    = np.zeros(3)
        self.pos_kf1   = np.zeros(3)
        self.pos_kf2   = np.zeros(3)
        self.pos_dm    = np.zeros(3)
        self.pos_voter = np.zeros(3)

        self.last_gps1 = np.zeros(2);  self.last_gps2 = np.zeros(2)
        self.last_lidar1 = 0.0;        self.last_lidar2 = 0.0
        self.last_acc = np.zeros(2);   self.last_gyro = np.zeros(3)
        self.res_gps   = 0.0
        self.res_lidar = 0.0
        self.res_imu   = 0.0
        self.kf1_min_cov = 1.0

        self._setup_situation(situation_id)

    def _setup_situation(self, sid: int):
        """Define flight route keyframes and fault injection schedules."""
        if sid == 1:
            self._sit_name = "Situation 1: GPS Hardware Fault (+5m X,Y)"
            self._sit_desc = "Drone takes off, accelerates rightwards down runway, performs circuit."
            self.keyframes = [
                ( 0.0, np.array([ 0.0,  0.0, 0.20])),
                ( 3.0, np.array([ 0.0,  0.0, 3.00])),  # Takeoff climb
                (14.0, np.array([20.0,  0.0, 3.00])),  # Fly rightwards down runway
                (22.0, np.array([20.0, -5.0, 3.00])),  # Turn south across airfield
                (33.0, np.array([ 0.0,  0.0, 3.00])),  # Return circuit to helipad
                (38.0, np.array([ 0.0,  0.0, 0.20])),  # Land on helipad
            ]
            self.fault_schedule = [(7.0, 'inj_gps', +5.0, +5.0), (15.8, 'rem_gps', 0, 0)]
        elif sid == 2:
            self._sit_name = "Situation 2: Lidar Hardware Fault (-1m Altitude)"
            self._sit_desc = "Drone takes off, flies rightwards along runway, performs circuit."
            self.keyframes = [
                ( 0.0, np.array([ 0.0, 0.0, 0.20])),
                ( 3.0, np.array([ 0.0, 0.0, 3.00])),  # Takeoff
                (14.0, np.array([18.0, 0.0, 3.50])),  # Fly right down runway
                (24.0, np.array([18.0, 5.0, 3.50])),  # Hold altitude & turn north
                (34.0, np.array([ 0.0, 0.0, 3.00])),  # Return to helipad
                (39.0, np.array([ 0.0, 0.0, 0.20])),  # Touchdown
            ]
            self.fault_schedule = [(17.8, 'inj_lidar', -1.0, 0)]
        elif sid == 3:
            self._sit_name = "Situation 3: Software Altitude Fault (KF1 P_z = -0.1)"
            self._sit_desc = "Drone takes off, flies right down runway past hangars & tower."
            self.keyframes = [
                ( 0.0, np.array([ 0.0,  0.0, 0.20])),
                ( 3.0, np.array([ 0.0,  0.0, 3.00])),  # Takeoff
                (14.0, np.array([20.0,  0.0, 3.00])),  # Fly rightwards along runway
                (24.0, np.array([10.0, -5.0, 3.00])),  # Circuit past hangars & control tower
                (34.0, np.array([ 0.0,  0.0, 3.00])),  # Return to helipad
                (39.0, np.array([ 0.0,  0.0, 0.20])),  # Land
            ]
            self.fault_schedule = []
        elif sid == 4:
            self._sit_name = "Situation 4: Software Position Fault (KF1 P_xy = -0.01)"
            self._sit_desc = "Long-range flight circuit down runway and across the airfield."
            self.keyframes = [
                ( 0.0, np.array([ 0.0, 0.0, 0.20])),
                ( 3.0, np.array([ 0.0, 0.0, 3.00])),  # Takeoff
                (16.0, np.array([28.0, 0.0, 3.00])),  # Fast flight rightwards down runway
                (28.0, np.array([28.0, 6.0, 3.00])),  # Circuit turn
                (40.0, np.array([ 0.0, 0.0, 3.00])),  # Return leg
                (45.0, np.array([ 0.0, 0.0, 0.20])),  # Touchdown
            ]
            self.fault_schedule = []
        self._fault_done = set()

    def get_smooth_target(self, t: float) -> tuple[np.ndarray, np.ndarray]:
        """Compute smooth continuous position and velocity via quintic smoothstep."""
        if t <= self.keyframes[0][0]:
            return self.keyframes[0][1], np.zeros(3)
        if t >= self.keyframes[-1][0]:
            return self.keyframes[-1][1], np.zeros(3)

        for i in range(len(self.keyframes) - 1):
            t0, p0 = self.keyframes[i]
            t1, p1 = self.keyframes[i + 1]
            if t0 <= t <= t1:
                dt_seg = max(t1 - t0, 1e-4)
                tau = np.clip((t - t0) / dt_seg, 0.0, 1.0)
                # Quintic smoothstep: s(tau) = 6*tau^5 - 15*tau^4 + 10*tau^3
                s = tau * tau * tau * (tau * (tau * 6.0 - 15.0) + 10.0)
                ds_dt = (30.0 * tau**4 - 60.0 * tau**3 + 30.0 * tau**2) / dt_seg
                pos = p0 + (p1 - p0) * s
                vel = (p1 - p0) * ds_dt
                return pos, vel
        return self.keyframes[-1][1], np.zeros(3)

    def _compute_wind(self, t: float) -> np.ndarray:
        gust_x = 1.4 * np.sin(0.4 * t) + 0.6 * np.sin(1.1 * t)
        gust_y = 1.1 * np.cos(0.3 * t) + 0.5 * np.sin(0.8 * t)
        turb_z = 0.3 * np.sin(0.9 * t)
        return self.mean_wind + np.array([gust_x, gust_y, turb_z])

    def step(self):
        """Execute one complete physics and estimation step."""
        if self.paused:
            return

        ctrl_dt = self.dt * self.ctrl_period

        # ── 1. Fault Schedule Injection ──────────────────────────────────────
        for i, sched in enumerate(self.fault_schedule):
            if i not in self._fault_done and self.t >= sched[0]:
                self._fault_done.add(i)
                kind = sched[1]
                if kind == 'inj_gps':
                    self.sb2.inject_gps_fault(sched[2], sched[3])
                    print(f"\n  [t={self.t:.2f}s] >>> GPS1 HARDWARE FAULT INJECTED (+{sched[2]}m X,Y)")
                elif kind == 'rem_gps':
                    self.sb2.remove_gps_fault()
                    print(f"\n  [t={self.t:.2f}s] >>> GPS1 Fault Cleared")
                elif kind == 'inj_lidar':
                    self.sb2.inject_lidar_fault(sched[2])
                    print(f"\n  [t={self.t:.2f}s] >>> LIDAR1 HARDWARE FAULT INJECTED ({sched[2]}m offset)")

        # ── 2. Wind & Rain Physics ───────────────────────────────────────────
        self.current_wind = self._compute_wind(self.t)
        self.rain.update(ctrl_dt, self.current_wind)

        # ── 3. Drone State Extraction ────────────────────────────────────────
        pos_gt   = self.data.qpos[:3].copy()
        vel_gt   = self.data.qvel[:3].copy()
        quat_gt  = self.data.qpos[3:7].copy()
        omega_gt = self.data.qvel[3:6].copy()
        euler_gt = quat_to_euler(quat_gt)

        # Aerodynamic Wind Drag
        v_rel = self.current_wind - vel_gt
        f_drag = 0.5 * 1.225 * 0.06 * np.linalg.norm(v_rel) * v_rel
        self.data.xfrc_applied[1, :3] = np.clip(f_drag, -2.0, 2.0)
        self.data.xfrc_applied[1, 3:] = 0.0

        acc_world = self.data.qacc[:3].copy()

        # ── 4. Redundant Sensor Readings ─────────────────────────────────────
        gps1   = self.sb2.read_gps(pos_gt[:2])
        gps2   = self.sb4.read_gps(pos_gt[:2])
        lidar1 = self.sb2.read_lidar(pos_gt[2])
        lidar2 = self.sb4.read_lidar(pos_gt[2])
        mag1   = self.sb2.read_magnetometer(euler_gt[2])
        mag2   = self.sb4.read_magnetometer(euler_gt[2])
        acc1   = self.sb1.read_accelerometer(acc_world)
        acc2   = self.sb3.read_accelerometer(acc_world)
        gyro1  = self.sb1.read_gyro(omega_gt)
        gyro2  = self.sb3.read_gyro(omega_gt)

        self.last_gps1 = gps1;  self.last_gps2 = gps2
        self.last_lidar1 = lidar1;  self.last_lidar2 = lidar2
        self.last_acc = acc1[:2];  self.last_gyro = gyro1

        # ── 5. EKF Multi-Branch Updates ──────────────────────────────────────
        self.kf1.predict(ctrl_dt, acc1);  self.kf1.correct_attitude(gyro1, ctrl_dt)
        self.kf1.correct_gps(gps1);       self.kf1.correct_lidar(lidar1)
        self.kf1.correct_magnetometer(mag1)

        self.kf2.predict(ctrl_dt, acc2);  self.kf2.correct_attitude(gyro2, ctrl_dt)
        self.kf2.correct_gps(gps2);       self.kf2.correct_lidar(lidar2)
        self.kf2.correct_magnetometer(mag2)

        # ── 6. Analytical Dynamic Model Branch ───────────────────────────────
        pwm_curr = self.data.ctrl[:4] * 1000 + 1500
        pwm_curr = np.clip(pwm_curr, 1000, 2000)
        self.dm.step(pwm_curr, wind=self.current_wind)

        # ── 7. Weighted Average Voter Consensus ──────────────────────────────
        p1 = self.kf1.position;  p2 = self.kf2.position;  p3 = self.dm.position
        voted_xy, s12, s13, s23 = self.voter_xy.euclidean_vote(p1[:2], p2[:2], p3[:2])
        alt_v, _, _, _, _       = self.voter_z.vote(p1[2], p2[2], p3[2])
        pos_voter = np.array([voted_xy[0], voted_xy[1], alt_v])

        if not self.fault_detected:
            self.dm.reset_position(pos_voter)

        # ── 8. Software & Hardware Fault Discriminator ───────────────────────
        res_gps_d = float(np.linalg.norm(gps1 - gps2))
        res_lidar = abs(lidar1 - lidar2)
        res_imu   = float(np.linalg.norm(acc1 - acc2))

        kf1_cov_diag = np.diag(self.kf1.state.P)
        self.kf1_min_cov = float(np.min(kf1_cov_diag))

        if (s12 < 0.1 or s13 < 0.1 or self.kf1_min_cov < 0.0) and not self.fault_detected:
            self.fault_detected = True
            self.recovery_active = True

            if res_gps_d > TH_GPS:
                self.fault_type = "HARDWARE"
                self.fault_name = "GPS1 Hardware Offset (+5m)"
                self.sb2.remove_gps_fault()
            elif res_lidar > TH_LIDAR:
                self.fault_type = "HARDWARE"
                self.fault_name = "Lidar1 Hardware Offset (-1m)"
                self.sb2.remove_lidar_fault()
            else:
                self.fault_type = "SOFTWARE"
                if self.kf1_min_cov < 0.0:
                    self.fault_name = f"KF1 Software Covariance Corruption (P_ii={self.kf1_min_cov:.2f})"
                else:
                    self.fault_name = "KF1 Estimator Divergence"

            print("\n" + "=" * 65)
            print(f"  [FAULT DETECTED] Time: {self.t:.2f}s")
            print(f"  Category: {self.fault_type} FAULT")
            print(f"  Details:  {self.fault_name}")
            print(f"  Sensors:  GPS_diff={res_gps_d:.2f}m, Lidar_diff={res_lidar:.2f}m, IMU_diff={res_imu:.3f}")
            print(f"  Recovery: Solution 3 Activated -> Disconnected KF1, KF3 = avg(KF2, DM)")
            print("=" * 65 + "\n")

        # ── 9. Flight Controller Command ─────────────────────────────────────
        target_pos, target_vel = self.get_smooth_target(self.t)
        if self.recovery_active:
            est_pos = self.kf2.position
            est_vel = self.kf2.velocity
        else:
            est_pos = pos_voter
            est_vel = self.kf1.velocity

        F_ctrl, pwm_cmd = self.ctrl.compute_thrusts(est_pos, est_vel, euler_gt, omega_gt,
                                                    target_pos, target_vel=target_vel, dt=ctrl_dt)
        self.data.ctrl[:4] = F_ctrl

        # ── 10. Propeller Spin Dynamics ──────────────────────────────────────
        spin_rates = np.clip(F_ctrl * 45.0 + 35.0, 20.0, 350.0)
        if len(self.data.qpos) >= 11:
            self.data.qpos[7]  += spin_rates[0] * self.dt
            self.data.qpos[8]  -= spin_rates[1] * self.dt
            self.data.qpos[9]  += spin_rates[2] * self.dt
            self.data.qpos[10] -= spin_rates[3] * self.dt

        # ── 11. Physics Step ─────────────────────────────────────────────────
        for _ in range(self.ctrl_period):
            mujoco.mj_step(self.model, self.data)
        self.t += ctrl_dt

        # ── 12. Telemetry Update ─────────────────────────────────────────────
        self.s12 = s12;  self.s13 = s13;  self.s23 = s23
        self.pos_gt    = pos_gt.copy()
        self.pos_kf1   = p1.copy()
        self.pos_kf2   = p2.copy()
        self.pos_dm    = p3.copy()
        self.pos_voter = pos_voter.copy()
        self.res_gps   = res_gps_d
        self.res_lidar = res_lidar
        self.res_imu   = res_imu

    def draw_custom_scene(self, scn: mujoco.MjvScene):
        """Render 3D falling rain and waypoint target beacon cleanly."""
        def add_capsule(p1, p2, radius, rgba):
            if scn.ngeom >= scn.maxgeom: return
            g = scn.geoms[scn.ngeom]
            mujoco.mjv_initGeom(g, mujoco.mjtGeom.mjGEOM_CAPSULE, np.zeros(3), np.zeros(3), np.zeros(9), np.array(rgba, dtype=np.float32))
            mujoco.mjv_connector(g, mujoco.mjtGeom.mjGEOM_CAPSULE, radius, p1, p2)
            scn.ngeom += 1

        def add_sphere(pos, radius, rgba):
            if scn.ngeom >= scn.maxgeom: return
            g = scn.geoms[scn.ngeom]
            mujoco.mjv_initGeom(g, mujoco.mjtGeom.mjGEOM_SPHERE, np.zeros(3), np.zeros(3), np.zeros(9), np.array(rgba, dtype=np.float32))
            g.size[:] = [radius, radius, radius]
            g.pos[:]  = pos
            scn.ngeom += 1

        self.rain.render(scn, self.pos_gt, self.current_wind)
        target, _ = self.get_smooth_target(self.t)
        add_sphere(target, 0.08, (1.0, 0.85, 0.1, 0.9))
        add_capsule(np.array([target[0], target[1], 0.0]), target, 0.003, (1.0, 0.85, 0.1, 0.18))

    def get_hud_corner_cards(self) -> tuple[str, str, str, str]:
        """Generate top-left and top-right corner HUD diagnostics cards."""
        wind_spd = float(np.linalg.norm(self.current_wind[:2]))
        wind_dir = np.arctan2(self.current_wind[1], self.current_wind[0]) * 180.0 / np.pi

        left_title = f"TAROT 650 UAV | FLIGHT TELEMETRY (SITUATION {self.situation_id})"
        left_text = (
            f"Time: {self.t:5.1f}s | Status: {'HEALTHY' if not self.fault_detected else 'FAULT DETECTED'}\n"
            f"Coordinates: X={self.pos_voter[0]:+5.1f}m  Y={self.pos_voter[1]:+5.1f}m  Z={self.pos_voter[2]:5.1f}m\n"
            f"Environment: Wind {wind_spd:3.1f} m/s @ {wind_dir:3.0f} deg | Rain: Active\n"
            f"Controls: [Left-Drag]=Orbit  [Scroll]=Zoom  [Space]=Pause"
        )

        right_title = "SENSOR & SOFTWARE DIAGNOSTICS"
        if not self.fault_detected:
            sw_status = "KF1: Nominal  KF2: Nominal  DM: Nominal"
            rec_status = "Recovery: Standby"
        elif self.fault_type == "SOFTWARE":
            sw_status = "KF1: [FAILED/CORRUPTED] -> ISOLATED"
            rec_status = "Recovery: ACTIVE (KF3=avg(KF2,DM))"
        else:
            sw_status = f"Hardware {self.fault_name} isolated"
            rec_status = "Recovery: ACTIVE (Sensor substitution)"

        right_text = (
            f"GPS Residual:   {self.res_gps:4.2f}m (Th=2.0m) -> {'[OK]' if self.res_gps <= TH_GPS else '[FAULT]'}\n"
            f"Lidar Residual: {self.res_lidar:4.2f}m (Th=1.0m) -> {'[OK]' if self.res_lidar <= TH_LIDAR else '[FAULT]'}\n"
            f"IMU Residual:   {self.res_imu:4.3f} m/s2 (Th=0.05) -> {'[OK]' if self.res_imu <= TH_IMU else '[FAULT]'}\n"
            f"Voter Agreement: s12={self.s12:.2f}  s13={self.s13:.2f}  s23={self.s23:.2f}\n"
            f"Software State: {sw_status}\n"
            f"{rec_status}"
        )
        return left_title, left_text, right_title, right_text

    def run(self):
        mujoco.mj_resetData(self.model, self.data)
        self.data.qpos[:3] = [0.0, 0.0, 0.205]
        self.data.qpos[3]  = 1.0
        mujoco.mj_forward(self.model, self.data)

        x0 = np.zeros(9)
        x0[:3] = [0.0, 0.0, 0.205]
        self.kf1.initialise(x0)
        self.kf2.initialise(x0)
        self.dm.initialise(x0[:3])

        print("\n" + "=" * 65)
        print("  TAROT 650 QUADROTOR 3D FLIGHT SIMULATION")
        print("  Based on: Hamadi et al., ISA Transactions 129 (2022)")
        print("=" * 65)
        print(f"  Active:     {self._sit_name}")
        print(f"  Scenario:   {self._sit_desc}")
        print( "  Conditions: Real-World Airfield + Dynamic Wind + Rain")
        print( "  HUD:        Corner diagnostics (center screen 100% clean).")
        print("=" * 65 + "\n")

        with mujoco.viewer.launch_passive(
                self.model, self.data,
                show_left_ui=False, show_right_ui=False) as viewer:

            viewer.cam.azimuth   = 135.0
            viewer.cam.elevation = -20.0
            viewer.cam.distance  = 2.30
            viewer.cam.lookat[:] = [0.0, 0.0, 0.5]

            print("  [Auto-Pilot] Taking off in rain/wind...")
            while viewer.is_running():
                step_start = time.time()
                self.step()

                # Camera tracks drone smoothly
                viewer.cam.lookat[:] = self.pos_gt

                with viewer.lock():
                    viewer.user_scn.ngeom = 0
                    self.draw_custom_scene(viewer.user_scn)

                lt, lx, rt, rx = self.get_hud_corner_cards()
                viewer.set_texts([
                    (mujoco.mjtGridPos.mjGRID_TOPLEFT,  None, lt, lx),
                    (mujoco.mjtGridPos.mjGRID_TOPRIGHT, None, rt, rx)
                ])

                viewer.sync()

                elapsed = time.time() - step_start
                target_dt = self.dt * self.ctrl_period
                if elapsed < target_dt:
                    time.sleep(target_dt - elapsed)

                if self.t > self.keyframes[-1][0] + 3.0:
                    print(f"\n  [Flight Complete] Mission finished at t={self.t:.1f}s.")
                    time.sleep(2.0)
                    break


# ─────────────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description='Tarot 650 3D Drone Simulator (Wind, Rain, Sensor/Software Diagnostics)')
    parser.add_argument('--situation', type=int, choices=[1, 2, 3, 4], default=0,
                        help='Situation: 1=GPS Fault, 2=Lidar Fault, 3=SW Alt Fault, 4=SW Pos Fault')
    args = parser.parse_args()

    sit_id = args.situation
    if sit_id == 0:
        print("\n" + "=" * 65)
        print("  TAROT 650 UAV - 3D REAL-WORLD DRONE SIMULATOR")
        print("  Data Fusion & Fault-Tolerance Strategy (Hamadi et al. 2022)")
        print("=" * 65)
        print("\n  Select Flight Situation:")
        print("  [1] Situation 1: GPS Hardware Fault in Wind/Rain   (+5m X,Y at t=7.0s)")
        print("  [2] Situation 2: Lidar Hardware Fault in Wind/Rain  (-1m Alt at t=17.8s)")
        print("  [3] Situation 3: Software Altitude Covariance Fault (KF1 P_z = -0.1)")
        print("  [4] Situation 4: Software Position Covariance Fault (KF1 P_xy = -0.01)")
        print()
        while True:
            try:
                choice = input("  Enter situation number [1-4] (default=1): ").strip()
                if choice == "":
                    sit_id = 1
                    break
                sit_id = int(choice)
                if sit_id in [1, 2, 3, 4]:
                    break
                print("  Please enter 1, 2, 3, or 4.")
            except (ValueError, KeyboardInterrupt):
                print("\n  Exiting.")
                return

    sim = Tarot650Simulation3D(situation_id=sit_id)
    sim.run()


if __name__ == '__main__':
    main()
